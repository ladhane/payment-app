import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import Backend from "i18next-xhr-backend";
import LanguageDetector from "i18next-browser-languagedetector";
import translationEN from "./locales/en.json";
import translationMR from "./locales/mr.json";
import translationHI from "./locales/hi.json";
import translationKN from "./locales/kn.json"
// import translationAR from "../public/assets/locales/ar/translation.json";
// import translationFR from "../public/assets/locales/fr/translation.json";

const fallbackLng = ["en"];
export const availableLanguages = ["en", "mr", "hi", "kn"];

const resources = {
  en: {
    translation: translationEN
  },
  mr: {
    translation: translationMR
  },
  hi: {
    translation: translationHI
  },
  kn: {
    translation: translationKN
  }
};

const DETECTION_OPTIONS = {
    order: ['navigator']
  };
  

i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    detection: DETECTION_OPTIONS,
    resources,
    fallbackLng,
    debug: false,
    whitelist: availableLanguages,
    interpolation: {
      escapeValue: false
    }
  });

  export function changeLanguage(lang) {
    if (availableLanguages.includes(lang)) {
      i18n.changeLanguage(lang);
    }
  }