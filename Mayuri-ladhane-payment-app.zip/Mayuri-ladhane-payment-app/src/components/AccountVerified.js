import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Check from '../assets/images/check-mark-png-45020.png';
import { useTranslation } from 'react-i18next';
import Header from './Header';

const AccountVerified = () => {
  const navigate = useNavigate();
  const {t} = useTranslation();

  //back click shouldnt land the user to /verfyingAccount page
  useEffect(() => {
    const handleBrowserBack = () => {
      navigate('/');
    };

    window.addEventListener('popstate', handleBrowserBack);
  }, [navigate]);

  return (
    <div className=' h-screen flex flex-col items-center justify-center lg:card'>
      <Header/>
      <img src={Check} alt='allSet' className='h-48' />
      <p className='m-10 text-xl'>{t("verifiedMsg")}</p>
    </div>
  );
};

export default AccountVerified;
