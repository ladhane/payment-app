import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Check from "../assets/images/check-mark-png-45020.png";
import Penny from "../assets/images/penny-drop.jpeg"
import { useTranslation } from 'react-i18next';

const VerifyingAccount = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [response, setResponse] = useState(null);  
  const {t} = useTranslation();
  const { accountNumber, holderName, ifscCode } = location?.state || {};

  useEffect(() => {
    //mock penny drop api
    const mockResponse = {
      success: true,
      message: "Penny drop successful!",
      data: {
        amount: 1,
        status: "processed",
      },
    };

    //timer used to give a effect that we are depositing 1 rupee to your account
    const timer = setTimeout(() => {
      setResponse(mockResponse);
      setIsLoading(false);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  // disabling the default back button behaviour
  useEffect(() => {
    const handleBrowserBack = () => {
      navigate('/');
    };

    window.addEventListener('popstate', handleBrowserBack);
  }, [navigate]);

  //redirecting to home page if user directly tries to hit /verifyingdetails page
  if (!location.state) {
    navigate("/");
    return null;
  }
  return (
      <div className="lg:card">
      <div className="flex justify-center mb-6">
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJJY6qzQfmILERhJmTOfF6_7-2vAh3qb65jBsqMSR6KQ&usqp=CAU&ec=48600112"
          alt="logo"
          className="bg-white h-24 rounded-full border border-black"
        ></img>
      </div>
      <div>
        <div className="mb-4 text-center">
          <p className="text-lg">{holderName}</p>
          <p className="font-bold text-xl">{accountNumber}</p>
        </div>
        <div className="mb-2">
          <p className="text-sm text-center">{ifscCode}</p>
        </div>
      </div>
      {isLoading && (
        <>
          <div className="flex justify-center mb-6">
            <img
              src={Penny}
              alt="logo"
              className="animate-waving-hand bg-white h-48 rounded-full border border-black mt-[10%]"
            ></img>
          </div>
          <div className="mb-2">
            <p className="text-lg text-center">
              {t("waitingMsg")}
            </p>
          </div>
        </>
      )}
      {!isLoading && response && (
        <>
          <div className="flex justify-center mb-6">
            <img
              src={Check}
              alt="logo"
              className="bg-white h-48 rounded-full"
            ></img>
          </div>
          <div className="mb-4">
            <p className="text-lg text-center">
              {t("confirmingMsg")}
            </p>
          </div>
          <div className="mt-8">
            <button
              type="submit"
              className="text-white bg-gray-900 hover:bg-gray-950 focus:ring-4 focus:outline-none focus:ring-gray-400 font-medium rounded-lg text-lg w-full p-2.5 text-center mb-4"
              onClick={() => navigate("/accountverified")}
            >
              {t("received")}
            </button>
            <button
              type="submit"
              className="text-white bg-gray-900 hover:bg-gray-950 focus:ring-4 focus:outline-none focus:ring-gray-400 font-medium rounded-lg text-lg w-full p-2.5 text-center mb-4"
              onClick={() => navigate("/accountfailure")}
            >
              {t("notReceived")}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default VerifyingAccount;
