import UserDetails from "./UserDetails";
import { Outlet, createBrowserRouter } from "react-router-dom";
import VerifyingAccount from "./VerifyingAccount";
// import Dropdown from "./Dropdown";
import AccountVerified from "./AccountVerified";
import AccountFailure from "./AccountFailure";


function App() {
  return (
    <div className="App h-screen flex flex-col items-center overflow-y-auto m-8">
      <Outlet/>
    </div>
  );
}

export const router = createBrowserRouter([{
  path: "/",
  element: <App />,
  children: [
    {
      path: "/",
      element: <UserDetails />,
    },{
      path: "/verifyingaccount",
      element: <VerifyingAccount />,
    },
  {
    path:"/accountverified",
    element:<AccountVerified/>
  },{
    path:"/accountfailure",
    element:<AccountFailure/>
  }]
}])

export default App;
