import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import codes from "../codes.json";
import { useNavigate } from "react-router";
import Header from "./Header";
import Dropdown from "./Dropdown";

const UserDetails = () => {
  const { t } = useTranslation();
  const [accountNumber, setAccountNumber] = useState("");
  const [reEnteredAccountNumber, setReEnteredAccountNumber] = useState("");
  const [IFSCcode, setIFSCcode] = useState("");
  const [isErrorName, setIsErrorName] = useState(false);
  const [isErrorAccNumber, setIsErrorAccNumber] = useState(false);
  const [isErrorReAccNumber, setIsErrorReAccNumber] = useState(false);
  const [isErrorIfsc, setIsErrorIfsc] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [accountHolder, setAccountHolder] = useState("");
  const navigate = useNavigate();

  //gives a list of ifsc codes
  const handleSearch = () => {
    const results = Object.entries(codes).filter(([code]) => code.includes(""));
    setSearchResults(results);
  };

  //function used when the user clicks on a specific ifsc code from search
  const handleSearchResultClick = (code) => {
    setIFSCcode(code);
    setIsErrorIfsc(false);
    setSearchResults([]);
  };

  //searches the typed ifsc code
  const searchResultsOfIfsc = (val) => {
    const data = Object.entries(codes).filter(([code]) => code.includes(val));
    setSearchResults(data);
    setIFSCcode(val);
  };

  //function that will allow the length of account number to be 20 only and not take the extra entered value and set it as accountNumber
  const handleChangeAccountNumber = (e) => {
    setIsErrorAccNumber(e.target.value.length > 19);
    const inputValue = e.target.value
      .toUpperCase()
      .replace(/[^0-9]/g, "")
      .substring(0, 20);
    setAccountNumber(inputValue);
  };

  // function that will check if the re-entered account number that the user is typing is same to the account number
  const handleChangeReEnteredAccountNumber = (e) => {
    const inputValue = e.target.value.toUpperCase().replace(/[^0-9]/g, "");
    setReEnteredAccountNumber(inputValue);
    setIsErrorReAccNumber(accountNumber !== inputValue);
  };

  //function that is called on submit to check if all the values are correct
  const handleForm = async () => {
    let hasErrors = false;

    if (
      !(accountNumber.length > 7 && accountNumber === reEnteredAccountNumber)
    ) {
      setIsErrorAccNumber(true);
      hasErrors = true;
    }

    if (!accountHolder) {
      setIsErrorName(true);
      hasErrors = true;
    }

    if (IFSCcode) {
      setIsErrorIfsc(false);
      try {
        const result = await fetch(`/${IFSCcode}`);
        const data = await result.json();

        if (!data.IFSC) {
          setIsErrorIfsc(true);
          hasErrors = true;
        }
      } catch (error) {
        console.error(error);
        hasErrors = true;
      }
    } else {
      setIsErrorIfsc(true);
      hasErrors = true;
    }
    if (!hasErrors) {
      navigate("/verifyingAccount", {
        state: {
          accountNumber: accountNumber,
          holderName: accountHolder,
          ifscCode: IFSCcode,
        },
      });
    }
  };

  const handleAccountHolder = (e) => {
    setAccountHolder(e.target.value);
    setIsErrorName(false);
  };

  return (
    <>
      <Dropdown />
      <div className="m-4 lg:card">
        <Header />
        <div className="mb-6">
          <input
            type="text"
            id="accountNumber"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-lg rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12"
            placeholder={t("enterAccountHoldersName")}
            value={accountHolder}
            onChange={handleAccountHolder}
            required
          />
          {isErrorName && <p className="text-red-500 mt-1">{t("enterName")}</p>}
        </div>
        <div className="mb-6">
          <input
            type="text"
            id="accountNumber"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-lg rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12"
            placeholder={t("enterAccNumber")}
            value={accountNumber}
            onChange={handleChangeAccountNumber}
            onClick={() => setSearchResults([])}
            required
          />
          {isErrorAccNumber && <p className="text-red-500 mt-1">{t("wrgValue")}</p>}
        </div>
        <div className="mb-6">
          <input
            type="text"
            id="reenterAccountNumber"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-lg rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12"
            placeholder={t("reenterAccountNumber")}
            value={reEnteredAccountNumber}
            onChange={handleChangeReEnteredAccountNumber}
            onClick={() => setSearchResults([])}
            required
          />
          {isErrorReAccNumber && <p className="text-red-500 mt-1">{t("eqAccNumber")}</p>}
        </div>
        <div className="mb-6">
          <div className="flex">
            <input
              type="text"
              id="ifscCode"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-lg rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pr-12"
              placeholder={t("enterIfscCode")}
              value={IFSCcode}
              onChange={(e) => {
                setIFSCcode(e.target.value);
                setIsErrorIfsc(false);
              }}
              onClick={() => setSearchResults([])}
            />
          </div>
          {isErrorIfsc && (
            <p className=" block text-red-500 mt-1">{t("wrgIfsc")}</p>
          )}
        </div>
        <p className="text-center mb-6">or</p>
        <div className="mb-6">
          <div className="flex">
            <input
              type="text"
              id="searchifscCode"
              className="bg-gray-50 border border-gray-300 border-r-0 text-gray-900 text-lg rounded-lg rounded-r-none focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 pr-12"
              placeholder={t("searchIfsc")}
              value={IFSCcode}
              onChange={(e) => searchResultsOfIfsc(e.target.value)}
              required
            />
            <button
              type="button"
              className="p-2.5 text-sm font-medium text-white bg-gray-50 rounded-r-lg border border-l-0 focus:ring-4 focus:outline-none focus:ring-blue-300 flex-none"
              onClick={handleSearch}
            >
              <svg
                aria-hidden="true"
                className="w-5 h-5"
                fill="none"
                stroke="black"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                ></path>
              </svg>
            </button>
          </div>
          {isErrorIfsc && (
            <p className=" block text-red-500 mt-1">{t("wrgIfsc")}</p>
          )}
          {searchResults.length > 0 && (
            <div className="mb-6 max-h-40 overflow-y-auto">
              <div className="mt-2 bg-white border border-gray-300 rounded shadow">
                {searchResults.map(([code, branch]) => (
                  <button
                    key={code}
                    className="p-2 border-b text-left block w-full"
                    onClick={() => handleSearchResultClick(code)}
                  >
                    <strong>{code}</strong>
                    <p>{branch}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mb-6">
          <button
            type="submit"
            className="text-white bg-gray-900 hover:bg-gray-950 focus:ring-4 focus:outline-none focus:ring-gray-400 font-medium rounded-lg text-lg w-full p-2.5 text-center"
            onClick={(e) => handleForm()}
          >
            {t("submit")}
          </button>
        </div>
      </div>
    </>
  );
};

export default UserDetails;
