import React from "react";

const Header = () => {
  return (
    <div className="flex justify-center mb-6">
      <img
        src="https://download.logo.wine/logo/Uber/Uber-Logo.wine.png"
        alt="logo"
        className="bg-white h-24"
      ></img>
    </div>
  );
};

export default Header;
