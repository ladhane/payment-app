import React, { useEffect } from "react";
import UnCheck from "../assets/images/cross.png";
import Header from "./Header";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";

const AccountFailure = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  //back click shouldnt land the user to /verfyingAccount page
  useEffect(() => {
    const handleBrowserBack = () => {
      navigate("/");
    };

    window.addEventListener("popstate", handleBrowserBack);
  }, [navigate]);
  return (
    <div className="h-screen flex flex-col items-center justify-center lg:card">
      <Header />
      <img src={UnCheck} alt="allSet" className="h-48 bg-white" />
      <p className="m-10 text-xl text-center">{t("notVerifiedMsg")}</p>
      <a href="/" className="m-10 text-xl text-center cursor-pointer underline">
        {" "}
        {t("tryAgain")}
      </a>
    </div>
  );
};

export default AccountFailure;
