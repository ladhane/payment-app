import React, { useState } from "react";
import { changeLanguage, availableLanguages } from "../i18n";

const languageMappings = {
  en: "English",
  mr: "मराठी",
  hi: "हिंदी",
  kn: "ಕನ್ನಡ",
};

const Dropdown = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [languages] = useState(availableLanguages.map((lang) => languageMappings[lang]));

  const handleLanguageChange = (lang) => {
    changeLanguage(lang);
    setIsDropdownOpen(false);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="relative inline-block ml-auto mr-4">
      <button
        className="flex items-center border-2 mt-2 rounded bg-primary px-4 pb-2 pt-2.5 text-xs transition duration-150 ease-in-out"
        type="button"
        id="dropdownMenuButton1"
        aria-expanded={isDropdownOpen}
        onClick={toggleDropdown}
      >
        Language
        <span className="ml-2 w-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
            className="h-5 w-5"
          >
            <path
              fillRule="evenodd"
              d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
              clipRule="evenodd"
            />
          </svg>
        </span>
      </button>
      {isDropdownOpen && (
        <ul
          className="absolute w-full py-2 bg-white border border-gray-200 shadow-lg rounded"
          aria-labelledby="dropdownMenuButton1"
        >
          {languages.map((lang) => (
            <li key={lang}>
              <button
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full"
                onClick={() => handleLanguageChange(Object.keys(languageMappings).find((key) => languageMappings[key] === lang))}
              >
                {lang}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Dropdown;

